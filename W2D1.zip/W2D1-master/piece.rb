#   require_relative "board"
class Piece
  def initialize
  end
end
