
class NullPiece < Piece
  def initialize
  end
end
